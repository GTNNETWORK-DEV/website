<?php
echo json_encode([
    "message" => "GTN Backend Running"
]);
